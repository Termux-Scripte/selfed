<?php 

?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Capture Image</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            text-align: center;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            max-width: 400px;
            width: 100%;
        }

        h1 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        video, canvas {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 20px;
            background-color: #000;
        }

        #snap {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        #snap:hover {
            background-color: #218838;
        }

        .credits {
            margin-top: 20px;
            font-size: 14px;
            color: #888;
        }

        .credits a {
            color: #28a745;
            text-decoration: none;
        }

        .credits a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>دوربین خود را فعال کنید</h1>
        <video id="video" autoplay></video>
        <button id="snap">عکس بگیرید</button>
        <canvas id="canvas" style="display:none;"></canvas>
        
        <div class="credits">
            ساخته شده توسط <a href="https://t.me/younes_poorghazi" target="_blank">@younes_poorghazi</a>
        </div>
    </div>

    <script>
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const context = canvas.getContext('2d');
        const snap = document.getElementById('snap');

        navigator.mediaDevices.getUserMedia({ video: true })
            .then((stream) => {
                video.srcObject = stream;
            })
            .catch((err) => {
                console.error("خطا در دسترسی به دوربین:", err);
            });

   
        snap.addEventListener("click", function() {
            canvas.style.display = 'block';
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = canvas.toDataURL('image/png');


            fetch('upload.php', {
                method: 'POST',
                body: JSON.stringify({ image: imageData }),
                headers: { 'Content-Type': 'application/json' }
            })
            .then(response => response.json())
            .then(data => {
                console.log('عکس با موفقیت ارسال شد:', data);
            })
            .catch((error) => {
                console.error('خطا در ارسال:', error);
            });
        });
    </script>

</body>
</html>
